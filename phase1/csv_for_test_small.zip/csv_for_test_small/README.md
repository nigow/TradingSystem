**README**

Admins: admin, admin1

Normal users: normal1, normal2, normal3

Frozen users: frozen1



Each normal user possesses an item with their individual name on it